<?php
/*
Template Name: 404

*/
?>
<?php get_header();?>
<?php wp_footer(); ?>