	<footer class="footer">
		<div class="footer__conatiner container">
			<div class="footer__logo-wrp">
				<div class="footer__logo img-wrp">
					<svg width="198" height="51" viewBox="0 0 198 51" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M16.1166 17.4915C16.1166 18.4407 15.2436 18.9153 33.9791 23.322C40.7615 24.9492 43.9177 28.5424 43.9177 31.8644C43.9177 45.3559 20.4815 47.5254 10.8115 47.5254C8.1926 47.5254 0 47.5254 0 43.5932C0 42.1695 2.35034 38.5763 3.42477 37.5593C4.2306 36.8814 8.1926 35.5932 9.19988 35.5932C9.53565 35.5932 9.7371 35.661 9.7371 36.0678C9.7371 36.7458 9.06558 37.0847 8.59551 37.3559C8.1926 37.6271 7.85684 37.9661 7.45392 38.3729V38.5085C31.4273 39.3898 38.0083 32.4068 38.0083 31.322C38.0083 27.8644 19.4071 25.1525 16.1837 24.6102C12.8261 24.0678 9.33419 22.9831 9.33419 18.9153C9.33419 16.678 10.4086 11.7288 11.4831 9.8983C13.5648 6.44068 25.7194 0 40.4258 0C43.2462 0 46.0666 0.338983 48.887 0.949152C50.4315 1.28814 50.6329 1.83051 50.6329 3.18644C50.6329 8.20339 48.9541 9.35593 44.9921 10.9153C42.1046 12 41.5674 12.339 38.9484 14.2373C38.4783 14.5085 37.8068 14.9153 37.2696 14.9153C36.5981 14.9153 36.1952 14.5763 36.1952 13.8983C36.1952 13.7627 37.4711 11.661 41.0973 9.15254L40.963 9.01695C23.6377 9.62712 16.1837 15.9322 16.1166 17.4915Z" fill="url(#paint0_linear_112_15)"/>
						<path d="M54.7235 27.2542L54.8578 27.3898C59.6256 22.9153 63.789 16.4068 64.9978 12.5424C61.7073 14.1695 57.8796 20.2712 54.7235 27.2542ZM67.8182 34.4407L68.7583 36.4746C65.0649 40.339 58.7526 47.1864 52.9775 47.1864C48.0754 47.1864 47.0009 42.3729 47.0009 38.3729C47.0009 31.2542 50.0228 23.5932 54.3877 18.1695C60.2971 10.7797 66.6766 4.47458 68.8255 4.47458C69.9671 4.47458 70.2357 6.1017 70.1685 6.98305C69.6985 13.4237 67.9525 19.3898 53.3804 33.6271C52.776 34.7797 52.5746 36.678 52.9104 38.3051C53.5147 39.8644 54.4549 41.2203 56.268 41.2203C59.9614 41.2203 65.1321 36.8814 67.8182 34.4407Z" fill="url(#paint1_linear_112_15)"/>
						<path d="M85.8691 35.1186L86.4734 37.6949C83.4516 41.4237 77.5422 47.5254 72.4386 47.5254C68.4766 47.5254 66.6635 42.9153 66.6635 39.4576C66.6635 31.1864 75.0575 23.1186 79.0867 23.1186C80.2283 23.1186 82.0414 23.5254 82.0414 25.017C82.0414 28.4068 75.3933 34.4407 72.5729 36.4068C72.0357 39.1864 73.043 40.678 76.132 40.678C79.6911 40.678 83.183 37.0847 85.8691 35.1186ZM82.7129 21.7627C81.1012 21.7627 80.0268 20.4746 80.0268 18.8475C80.0268 16.0678 83.2501 13.6271 85.8691 13.6271C87.0778 13.6271 88.0851 14.5085 88.0851 15.7288C88.0851 18.4407 85.6005 21.7627 82.7129 21.7627Z" fill="url(#paint2_linear_112_15)"/>
						<path d="M104.156 26.8475C105.432 25.1525 108.387 21.2203 110.737 21.2203C112.08 21.2203 112.752 22.1017 112.752 23.4576C112.752 26.1695 108.857 32.5424 107.178 34.9153C107.917 35.5932 108.387 35.7966 109.461 35.7966C111.207 35.7966 113.692 34.1017 115.169 33.0847L115.639 35.9322C113.289 38.6441 110.804 40.7458 107.044 40.7458C105.633 40.7458 104.693 39.7966 103.552 38.9831C101.671 41.1525 94.889 47.1186 92.2701 47.1186C88.3081 47.1186 85.622 42.0339 85.622 36.8814C85.622 27.5254 93.8817 21.0169 96.2321 21.0169C97.1722 21.0169 100.261 21.1525 100.261 22.5763C100.261 25.6271 93.9489 32.4746 91.5314 34.5085C91.1956 35.5932 90.5241 37.4237 90.5241 38.5085C90.5241 39.5932 90.7927 41.1525 92.1358 41.1525C94.0832 41.1525 99.3882 36.2034 100.798 34.8475C100.53 31.7288 102.343 29.1525 104.156 26.8475Z" fill="url(#paint3_linear_112_15)"/>
						<path d="M146.785 4C146.785 8.67797 122.811 31.1186 118.782 35.5932L118.648 37.4237C122.274 34.1017 136.51 21.6949 141.077 21.6949C143.36 21.6949 144.569 24.6102 144.569 26.5763C144.569 32.8814 135.503 36.339 131.004 39.0508C132.28 40.8136 133.018 41.8983 135.369 42.0339C136.645 42.1017 139.264 41.1525 147.591 34.4407L148.262 37.2203C144.904 40.2034 136.846 48 132.347 48C127.915 48 124.826 42.8475 122.744 39.5932C121.267 40.9492 120.192 42.5085 119.185 44.2034C118.648 45.2203 118.043 46.2373 116.768 46.2373C114.417 46.2373 113.813 39.661 113.813 38.0339C113.813 33.6949 116.499 30.1695 118.782 26.5763C126.035 15.0508 142.151 2.0339 145.106 2.23729C146.046 2.30509 146.785 3.05085 146.785 4ZM129.124 37.0847L135.436 32.678C136.443 31.9322 138.659 30.5085 138.659 29.0847C138.659 28.678 138.122 28.5424 137.786 28.5424C135.302 28.5424 128.251 33.2881 126.572 35.5932C127.512 35.9322 128.385 36.4068 129.124 37.0847Z" fill="url(#paint4_linear_112_15)"/>
						<path d="M165.678 35.1186L166.283 37.6949C163.261 41.4237 157.351 47.5254 152.248 47.5254C148.286 47.5254 146.473 42.9153 146.473 39.4576C146.473 31.1864 154.867 23.1186 158.896 23.1186C160.037 23.1186 161.85 23.5254 161.85 25.017C161.85 28.4068 155.202 34.4407 152.382 36.4068C151.845 39.1864 152.852 40.678 155.941 40.678C159.5 40.678 162.992 37.0847 165.678 35.1186ZM162.522 21.7627C160.91 21.7627 159.836 20.4746 159.836 18.8475C159.836 16.0678 163.059 13.6271 165.678 13.6271C166.887 13.6271 167.894 14.5085 167.894 15.7288C167.894 18.4407 165.41 21.7627 162.522 21.7627Z" fill="url(#paint5_linear_112_15)"/>
						<path d="M193.434 36.4746L197.463 33.0847L198 36.0678C194.441 39.2542 187.524 47.5932 182.622 47.5932C180.07 47.5932 178.862 45.4237 178.862 43.1186C178.862 39.0508 182.488 34.5763 184.637 31.4576L184.502 31.322C180.608 34.2373 177.183 37.7627 174.161 41.6949C173.154 42.9831 170.669 46.3051 168.856 46.3051C165.901 46.3051 165.162 42.0339 165.095 39.7288C164.894 35.0508 169.124 28.2034 173.019 24.8814C173.892 24.1356 174.497 24.0678 175.638 24.0678C179.667 24.2034 179.332 25.1525 179.332 25.5593C179.332 28.2034 170.87 35.0508 170.87 36.678C170.87 37.0847 171.206 37.4237 171.609 37.4237C172.079 37.4237 172.684 36.8136 172.952 36.4746C178.324 29.5593 190.68 21.2203 192.628 21.2203C192.896 21.2203 193.299 21.5593 193.702 22.5085C194.105 23.5254 194.508 24.7458 194.71 26.1695C194.71 28.8136 186.45 33.9661 186.45 38.6441C186.45 39.2542 186.987 39.8644 187.659 39.8644C189.27 39.8644 192.225 37.4915 193.434 36.4746Z" fill="url(#paint6_linear_112_15)"/>
						<defs>
						<linearGradient id="paint0_linear_112_15" x1="71.7859" y1="-35.4124" x2="178.856" y2="45.5225" gradientUnits="userSpaceOnUse">
						<stop stop-color="#00D49A"/>
						<stop offset="0.317708" stop-color="#8E8CF2"/>
						<stop offset="0.635417" stop-color="#ED54A1"/>
						<stop offset="1" stop-color="#F2BF1E"/>
						</linearGradient>
						<linearGradient id="paint1_linear_112_15" x1="71.7859" y1="-35.4124" x2="178.856" y2="45.5225" gradientUnits="userSpaceOnUse">
						<stop stop-color="#00D49A"/>
						<stop offset="0.317708" stop-color="#8E8CF2"/>
						<stop offset="0.635417" stop-color="#ED54A1"/>
						<stop offset="1" stop-color="#F2BF1E"/>
						</linearGradient>
						<linearGradient id="paint2_linear_112_15" x1="71.7859" y1="-35.4124" x2="178.856" y2="45.5225" gradientUnits="userSpaceOnUse">
						<stop stop-color="#00D49A"/>
						<stop offset="0.317708" stop-color="#8E8CF2"/>
						<stop offset="0.635417" stop-color="#ED54A1"/>
						<stop offset="1" stop-color="#F2BF1E"/>
						</linearGradient>
						<linearGradient id="paint3_linear_112_15" x1="71.7859" y1="-35.4124" x2="178.856" y2="45.5225" gradientUnits="userSpaceOnUse">
						<stop stop-color="#00D49A"/>
						<stop offset="0.317708" stop-color="#8E8CF2"/>
						<stop offset="0.635417" stop-color="#ED54A1"/>
						<stop offset="1" stop-color="#F2BF1E"/>
						</linearGradient>
						<linearGradient id="paint4_linear_112_15" x1="71.7859" y1="-35.4124" x2="178.856" y2="45.5225" gradientUnits="userSpaceOnUse">
						<stop stop-color="#00D49A"/>
						<stop offset="0.317708" stop-color="#8E8CF2"/>
						<stop offset="0.635417" stop-color="#ED54A1"/>
						<stop offset="1" stop-color="#F2BF1E"/>
						</linearGradient>
						<linearGradient id="paint5_linear_112_15" x1="71.7859" y1="-35.4124" x2="178.856" y2="45.5225" gradientUnits="userSpaceOnUse">
						<stop stop-color="#00D49A"/>
						<stop offset="0.317708" stop-color="#8E8CF2"/>
						<stop offset="0.635417" stop-color="#ED54A1"/>
						<stop offset="1" stop-color="#F2BF1E"/>
						</linearGradient>
						<linearGradient id="paint6_linear_112_15" x1="71.7859" y1="-35.4124" x2="178.856" y2="45.5225" gradientUnits="userSpaceOnUse">
						<stop stop-color="#00D49A"/>
						<stop offset="0.317708" stop-color="#8E8CF2"/>
						<stop offset="0.635417" stop-color="#ED54A1"/>
						<stop offset="1" stop-color="#F2BF1E"/>
						</linearGradient>
						</defs>
					</svg>
				</div>
				<span class="footer__logo-text text-small">
					<?php echo get_post_meta(get_the_ID(), 'footer_text', true);?>
				</span>
			</div>
			<div class="footer__info-text-wrp">
				<span class="footer__info-text text-small"><?php echo get_post_meta(get_the_ID(), 'footer_text2', true);?></span>
				<span class="footer__info-text text-small"><?php echo get_post_meta(get_the_ID(), 'footer_text3', true);?></span>
			</div>

			<a href="<?php bloginfo('template_url'); ?>/assets/pol.pdf" target="_blank" class="footer__link-police text-small police-link">политикой конфиденциальности</a>
		</div>
	</footer>

	<!-- popups -->
	<div class="popup-backgrounds"></div>
	<div class="popup-background" id="popup__form">
		<form action="<?php echo admin_url('admin-ajax.php?action=callback_mail') ?>" method="post" class="popup__form popup-body main-form myForm">
			<div class="wrp">
				<div class="popup__form-title text-big"><?php echo get_post_meta(get_the_ID(), 's5_form-title', true);?></div>

				<input class="main-form__input text-big" type="text" id="name2" name="name2" placeholder="Ваше имя" style="border: 2rem solid #fff">
				<span id="nameError2" style="color: red;"></span>
				<input class="main-form__input text-big" type="text" id="phone2" name="phone2" placeholder="Ваш телефон" style="border: 2rem solid #fff">
				<span id="phoneError2" style="color: red;"></span>

				<span class="main-form__text text-small">
					<?php echo get_post_meta(get_the_ID(), 'form_desc-text', true);?> <a href="<?php bloginfo('template_url'); ?>/assets/pol.pdf" target="_blank" class="police-link">политикой конфиденциальности</a>
				</span>
			    <div style="display: none;">
                    <label>Не заполняйте это поле:</label>
                    <input type="text" name="honey" id="honey">
                </div>
				<button type="submit" class="main-form__btn main-btn">отправить заявку</button>
				<div class="popup__form-exit closePopupButton">
					<div class="popup__form-exit-icon img-wrp">
						<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
							<path d="M18 6L6 18" stroke="#6113E1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
							<path d="M6 6L18 18" stroke="#6113E1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
						</svg>
					</div>
				</div>
			</div>
			<div class="popup-decor__icon popup-decor__icon1 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.15s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-star.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon2 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.25s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-box.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon3 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.30s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-5cut.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon4 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.35s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-snake.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon5 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.40s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-3cut.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon6 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.45s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-5cut-big.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon7 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.5s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-boll.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon8 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.55s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-moln.webp" alt="icon">
			</div>
		</form>
	</div>

	<div class="popup-background" id="popup__form-end">
		<div class="popup__form-end popup-body">
			<div class="wrp">
				<div class="popup__form-end-icon img-wrp">
					<img src="<?php bloginfo('template_url'); ?>/assets/image/ok.webp" alt="img">
				</div>
				<div class="popup__form-end-title text-big">спасибо</div>
				<div class="popup__form-end-text text-small">
					ваша заявка заполнена <br>
					наш оператор с вами свяжется в ближайшее время
				</div>
				<button class="popup__form-end-btn main-btn closePopupButton">закрыть окно</butto>
			</div>
			<div class="popup-decor__icon popup-decor__icon1 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.15s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-star.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon2 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.25s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-box.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon3 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.35s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-5cut.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon4 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.45s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-snake.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon5 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.55s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-3cut.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon6 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.65s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-5cut-big.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon7 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.75s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-boll.webp" alt="icon">
			</div>
			<div class="popup-decor__icon popup-decor__icon8 img-wrp wow animate__animated animate__zoomIn" data-wow-delay="0.85s">
				<img src="<?php bloginfo('template_url'); ?>/assets/image/icons-popup/popup-icon-moln.webp" alt="icon">
			</div>
		</div>
	</div>

	<div class="popup-background" id="police-popup">
		<div class="popup-content police-popup">
			<div class="popup__form-exit closePopupButton">
				<div class="popup__form-exit-icon img-wrp">
					<svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M18 6L6 18" stroke="#6113E1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
						<path d="M6 6L18 18" stroke="#6113E1" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"/>
					</svg>
				</div>
			</div>
		</div>
	</div>
	<!-- END popups -->

    <!-- yandex -->

    <?php wp_footer(); ?>

	<!-- swiper js -->
	<!-- <link rel="stylesheet" href="libs/swiperjs/swiper.css"> -->
	<!-- <script src="libs/swiperjs/swiper.min.js"></script> -->

	<!-- wow js -->
	<!-- <link rel="stylesheet" href="libs/animatecss/animate.css"> -->
	<!-- <script src="libs/wowjs/wow.min.js"></script> -->

	<!-- main js -->
	<!-- <script src="scripts/main.js"></script> -->

</body>
</html>
